rm -rf /data/vendor/wifi
for i in `find "/vendor/etc/wifi" -type f`; do
        mktouch "$Module/system/$i"
done